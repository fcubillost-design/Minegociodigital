
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { View, Transaction, TransactionType } from './types';
import { GASTO_CATEGORIES, INGRESO_CATEGORIES } from './constants';
import { getBusinessAdvice } from './services/geminiService';
import { Card } from './components/common/Card';
import { EquilibriumCalculator } from './components/common/EquilibriumCalculator';

const Header: React.FC = () => (
    <header className="bg-primary text-white p-4 shadow-lg flex items-center justify-between">
        <div className="flex items-center space-x-3">
            <i className="fas fa-star text-accent text-3xl"></i>
            <h1 className="text-2xl font-bold">Gerenciando Mi Negocio AI</h1>
        </div>
    </header>
);

const TransactionForm: React.FC<{ addTransaction: (tx: Omit<Transaction, 'id'>) => void; closeModal: () => void }> = ({ addTransaction, closeModal }) => {
    const [type, setType] = useState<TransactionType>(TransactionType.GASTO);
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!amount || !category) {
            alert("Por favor, completa el monto y la categoría.");
            return;
        }
        addTransaction({
            type,
            amount: parseFloat(amount),
            category,
            description,
            date: new Date().toISOString(),
        });
        closeModal();
    };

    const categories = type === TransactionType.GASTO ? GASTO_CATEGORIES : INGRESO_CATEGORIES;
    useEffect(() => {
        if(categories.length > 0) {
            setCategory(categories[0]);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type]);


    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="w-11/12 max-w-lg">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <h2 className="text-2xl font-bold text-center">Registrar Movimiento</h2>
                    <div className="flex justify-center space-x-4">
                        <button type="button" onClick={() => setType(TransactionType.GASTO)} className={`px-6 py-2 rounded-full font-semibold ${type === TransactionType.GASTO ? 'bg-secondary text-white' : 'bg-gray-200'}`}>Gasto</button>
                        <button type="button" onClick={() => setType(TransactionType.INGRESO)} className={`px-6 py-2 rounded-full font-semibold ${type === TransactionType.INGRESO ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>Ingreso</button>
                    </div>
                    <div>
                        <label className="block font-medium">Monto</label>
                        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Ej: 15000" className="w-full p-2 border rounded-md" required />
                    </div>
                    <div>
                        <label className="block font-medium">Categoría</label>
                        <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full p-2 border rounded-md" required>
                           {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block font-medium">Descripción (Opcional)</label>
                        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ej: Compra de mercadería" className="w-full p-2 border rounded-md" />
                    </div>
                    <div className="flex justify-end space-x-3">
                         <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-300 rounded-md font-semibold">Cancelar</button>
                         <button type="submit" className="px-4 py-2 bg-primary text-white rounded-md font-semibold">Guardar</button>
                    </div>
                </form>
            </Card>
        </div>
    );
};

const Dashboard: React.FC<{ transactions: Transaction[], openModal: () => void, setView: (view: View) => void }> = ({ transactions, openModal, setView }) => {
    const { totalIncome, totalExpenses, balance } = useMemo(() => {
        const income = transactions.filter(tx => tx.type === TransactionType.INGRESO).reduce((sum, tx) => sum + tx.amount, 0);
        const expenses = transactions.filter(tx => tx.type === TransactionType.GASTO).reduce((sum, tx) => sum + tx.amount, 0);
        return { totalIncome: income, totalExpenses: expenses, balance: income - expenses };
    }, [transactions]);
    
    const formatCurrency = (value: number) => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value);

    return (
        <div className="p-4 space-y-6">
            <Card className="bg-primary text-white">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="text-lg">Saldo Actual</p>
                        <p className="text-4xl font-bold">{formatCurrency(balance)}</p>
                    </div>
                    <i className="fas fa-wallet text-5xl opacity-50"></i>
                </div>
            </Card>

            <div className="grid grid-cols-2 gap-4">
                <Card className="text-center bg-green-50">
                    <p className="text-sm text-green-700">Ingresos del Mes</p>
                    <p className="text-2xl font-bold text-green-800">{formatCurrency(totalIncome)}</p>
                </Card>
                 <Card className="text-center bg-red-50">
                    <p className="text-sm text-red-700">Gastos del Mes</p>
                    <p className="text-2xl font-bold text-red-800">{formatCurrency(totalExpenses)}</p>
                </Card>
            </div>
            
             <button onClick={openModal} className="w-full py-4 bg-secondary text-white rounded-lg font-bold text-xl shadow-lg hover:bg-red-700 transition-colors flex items-center justify-center space-x-2">
                <i className="fas fa-plus-circle"></i>
                <span>Anotar Rápido</span>
            </button>

            <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setView(View.COACH)}>
                 <div className="flex items-center space-x-4">
                    <i className="fas fa-brain text-4xl text-accent"></i>
                    <div>
                        <h2 className="text-xl font-bold">Asesor IA</h2>
                        <p className="text-gray-600">Recibe un consejo personalizado para tu negocio.</p>
                    </div>
                </div>
            </Card>

             <h2 className="text-xl font-bold pt-4">Tus Movimientos Recientes</h2>
             {transactions.length === 0 ? (
                <p className="text-center text-gray-500 py-4">No hay movimientos todavía. ¡Añade tu primer ingreso o gasto!</p>
             ) : (
                <div className="space-y-3">
                    {transactions.slice(0, 5).map(tx => (
                        <Card key={tx.id} className="flex justify-between items-center">
                            <div>
                               <p className="font-bold">{tx.category}</p>
                               <p className="text-sm text-gray-500">{tx.description || new Date(tx.date).toLocaleDateString('es-CL')}</p>
                            </div>
                            <p className={`font-bold text-lg ${tx.type === TransactionType.INGRESO ? 'text-green-600' : 'text-red-600'}`}>
                                {tx.type === TransactionType.INGRESO ? '+' : '-'} {formatCurrency(tx.amount)}
                            </p>
                        </Card>
                    ))}
                </div>
             )}
        </div>
    );
};

const AICoachView: React.FC<{transactions: Transaction[]}> = ({transactions}) => {
    const [advice, setAdvice] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    
    const financialSummary = useMemo(() => {
        const income = transactions.filter(tx => tx.type === TransactionType.INGRESO).reduce((sum, tx) => sum + tx.amount, 0);
        const expenses = transactions.filter(tx => tx.type === TransactionType.GASTO).reduce((sum, tx) => sum + tx.amount, 0);
        const balance = income - expenses;
        const topExpenses = transactions
            .filter(tx => tx.type === TransactionType.GASTO)
            .reduce((acc, tx) => {
                acc[tx.category] = (acc[tx.category] || 0) + tx.amount;
                return acc;
            }, {} as Record<string, number>);

        const sortedTopExpenses = Object.entries(topExpenses)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 3)
            .map(([category]) => category)
            .join(', ');

        return `
        - Resumen financiero del último mes:
          - Ingresos totales: ${income.toLocaleString('es-CL', {style: 'currency', currency: 'CLP'})}
          - Gastos totales: ${expenses.toLocaleString('es-CL', {style: 'currency', currency: 'CLP'})}
          - Saldo: ${balance.toLocaleString('es-CL', {style: 'currency', currency: 'CLP'})}
          - Las categorías con más gastos son: ${sortedTopExpenses || 'ninguna registrada'}.
        `;
    }, [transactions]);
    
    const handleGetAdvice = useCallback(async () => {
        setIsLoading(true);
        setAdvice('');
        const newAdvice = await getBusinessAdvice(financialSummary);
        setAdvice(newAdvice);
        setIsLoading(false);
    }, [financialSummary]);

    return (
        <div className="p-4 space-y-4">
            <Card>
                <h2 className="text-2xl font-bold text-center mb-2">Tu Coach de Negocios IA</h2>
                <p className="text-center text-gray-600 mb-4">Presiona el botón para recibir un consejo basado en tus finanzas y los principios de "Gerenciando mi Negocio".</p>
                <button onClick={handleGetAdvice} disabled={isLoading} className="w-full py-3 bg-accent text-primary font-bold rounded-lg shadow-md hover:bg-yellow-400 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed">
                    {isLoading ? 'Pensando...' : '¡Dame un consejo!'}
                </button>
            </Card>
            {isLoading && (
                <div className="flex justify-center items-center p-8">
                    <i className="fas fa-spinner fa-spin text-4xl text-primary"></i>
                </div>
            )}
            {advice && (
                <Card className="bg-blue-50 border-l-4 border-primary">
                    <div className="flex space-x-4">
                        <i className="fas fa-brain text-2xl text-primary mt-1"></i>
                        <p className="text-dark whitespace-pre-wrap">{advice}</p>
                    </div>
                </Card>
            )}
        </div>
    );
};


const BottomNav: React.FC<{ activeView: View; setView: (view: View) => void }> = ({ activeView, setView }) => {
    const navItems = [
        { view: View.DASHBOARD, icon: 'fa-home', label: 'Inicio' },
        { view: View.ANALISIS, icon: 'fa-chart-pie', label: 'Análisis' },
        { view: View.CAPACITACION, icon: 'fa-book-open', label: 'Aprender' },
    ];

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_5px_rgba(0,0,0,0.1)] flex justify-around">
            {navItems.map(item => (
                <button
                    key={item.view}
                    onClick={() => setView(item.view)}
                    className={`flex-1 flex flex-col items-center justify-center py-2 text-sm transition-colors ${
                        activeView === item.view ? 'text-primary' : 'text-gray-500 hover:text-primary'
                    }`}
                >
                    <i className={`fas ${item.icon} text-xl`}></i>
                    <span className="mt-1">{item.label}</span>
                </button>
            ))}
        </nav>
    );
};

const App: React.FC = () => {
    const [view, setView] = useState<View>(View.DASHBOARD);
    const [transactions, setTransactions] = useState<Transaction[]>(() => {
        try {
            const saved = localStorage.getItem('transactions');
            return saved ? JSON.parse(saved) : [];
        } catch (error) {
            return [];
        }
    });
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        localStorage.setItem('transactions', JSON.stringify(transactions));
    }, [transactions]);

    const addTransaction = (tx: Omit<Transaction, 'id'>) => {
        setTransactions(prev => [{ ...tx, id: new Date().getTime().toString() }, ...prev]);
    };

    const renderView = () => {
        switch (view) {
            case View.DASHBOARD:
                return <Dashboard transactions={transactions} openModal={() => setIsModalOpen(true)} setView={setView} />;
            case View.ANALISIS:
                return <div className="p-4"><Card><EquilibriumCalculator /></Card></div>;
            case View.CAPACITACION:
                return <div className="p-4 text-center"><Card><h2 className="text-xl font-bold">Capacitación</h2><p className="mt-2 text-gray-600">Módulo de capacitación próximamente disponible.</p></Card></div>;
            case View.COACH:
                return <AICoachView transactions={transactions} />;
            default:
                return <Dashboard transactions={transactions} openModal={() => setIsModalOpen(true)} setView={setView} />;
        }
    };

    return (
        <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-grow pb-20">
              {renderView()}
            </main>
            {isModalOpen && <TransactionForm addTransaction={addTransaction} closeModal={() => setIsModalOpen(false)} />}
            <BottomNav activeView={view} setView={setView} />
        </div>
    );
};

export default App;
