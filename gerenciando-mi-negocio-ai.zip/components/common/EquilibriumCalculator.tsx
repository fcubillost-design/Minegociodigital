import React, { useState, useMemo } from 'react';
import { askGemini } from '../../lib/gemini';
import { promptPuntoEquilibrio } from '../../lib/prompts';
import { Card } from './Card';


export const EquilibriumCalculator: React.FC = () => {
    const [fixedCosts, setFixedCosts] = useState('');
    const [unitPrice, setUnitPrice] = useState('');
    const [variableCost, setVariableCost] = useState('');
    const [advice, setAdvice] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value);
    };

    const breakEvenPoint = useMemo(() => {
        const fc = parseFloat(fixedCosts);
        const up = parseFloat(unitPrice);
        const vc = parseFloat(variableCost);

        if (fc > 0 && up > 0 && vc >= 0 && up > vc) {
            const point = fc / (up - vc);
            return {
                units: Math.ceil(point),
                revenue: Math.ceil(point) * up
            };
        }
        return null;
    }, [fixedCosts, unitPrice, variableCost]);

    const handleGetAdvice = async () => {
        if(!breakEvenPoint) {
            alert("Primero calcula un punto de equilibrio válido.");
            return;
        }
        setIsLoading(true);
        setAdvice('');
        try {
            const P = parseFloat(unitPrice);
            const CV = parseFloat(variableCost);
            const CF = parseFloat(fixedCosts);
            const context = {
                rubro: "un pequeño negocio (sin especificar rubro)",
                P,
                CV,
                CF,
            };
            const result = await askGemini({
                systemPrompt: promptPuntoEquilibrio.system,
                userPrompt: promptPuntoEquilibrio.user(context),
            });
            setAdvice(result);
        } catch (error) {
            console.error(error);
            setAdvice("Hubo un error al obtener la sugerencia. Intenta de nuevo.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card className="space-y-4">
            <h3 className="text-xl font-bold text-dark">Calculadora de Punto de Equilibrio</h3>
            <p className="text-gray-600">Descubre cuántas unidades necesitas vender para cubrir todos tus costos.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label htmlFor="fixedCosts" className="block text-sm font-medium text-gray-700">Costos Fijos Totales ($)</label>
                    <input
                        type="number"
                        id="fixedCosts"
                        value={fixedCosts}
                        onChange={(e) => setFixedCosts(e.target.value)}
                        placeholder="Ej: 500000"
                        className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    />
                </div>
                <div>
                    <label htmlFor="unitPrice" className="block text-sm font-medium text-gray-700">Precio de Venta Unitario ($)</label>
                    <input
                        type="number"
                        id="unitPrice"
                        value={unitPrice}
                        onChange={(e) => setUnitPrice(e.target.value)}
                        placeholder="Ej: 10000"
                        className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    />
                </div>
                <div>
                    <label htmlFor="variableCost" className="block text-sm font-medium text-gray-700">Costo Variable Unitario ($)</label>
                    <input
                        type="number"
                        id="variableCost"
                        value={variableCost}
                        onChange={(e) => setVariableCost(e.target.value)}
                        placeholder="Ej: 4000"
                        className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    />
                </div>
            </div>
            {breakEvenPoint && (
                <div className="mt-6 p-4 bg-green-100 border-l-4 border