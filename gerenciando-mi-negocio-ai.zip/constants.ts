
export const GASTO_CATEGORIES: string[] = [
  'Arriendo',
  'Materias Primas',
  'Sueldos',
  'Servicios (Luz, Agua)',
  'Transporte',
  'Marketing',
  'Impuestos',
  'Otros',
];

export const INGRESO_CATEGORIES: string[] = [
  'Venta de Producto',
  'Venta de Servicio',
  'Otros Ingresos',
];