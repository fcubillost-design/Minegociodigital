
import { GoogleGenAI } from "@google/genai";

// Ensure API_KEY is available in the environment.
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.error("API_KEY for Gemini is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getBusinessAdvice = async (context: string): Promise<string> => {
  if (!API_KEY) {
    return "Error: La clave de API para el servicio de IA no está configurada. Por favor, contacta al soporte.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `
Eres 'Desafío Coach', un asesor de negocios experto para micro-emprendedores en Chile. Tu conocimiento se basa en el manual 'Gerenciando mi Negocio'. Eres amigable, práctico y usas un lenguaje sencillo y motivador.

Contexto del negocio del usuario:
${context}

Basado en este contexto y en los principios del manual 'Gerenciando mi Negocio', entrega un consejo corto, práctico y accionable (máximo 80 palabras) para mejorar su negocio esta semana. Enfócate en conceptos como control de gastos, ideas para aumentar ventas, o la importancia de separar las finanzas personales de las del negocio. No uses jerga financiera. Termina con una pregunta que invite a la reflexión. Tu respuesta debe ser solo texto, sin formato markdown.
              `,
            },
          ],
        },
      ],
      config: {
        temperature: 0.7,
        topP: 0.95,
        topK: 64,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error fetching advice from Gemini:", error);
    return "Hubo un problema al contactar al Asesor IA. Por favor, intenta de nuevo más tarde.";
  }
};