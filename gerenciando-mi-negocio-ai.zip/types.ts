export enum View {
  DASHBOARD = 'DASHBOARD',
  FINANZAS = 'FINANZAS',
  MARKETING = 'MARKETING',
  CAPACITACION = 'CAPACITACION',
}

export enum TransactionType {
  INGRESO = 'ingreso',
  GASTO = 'gasto',
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  date: string;
}

export interface CostoItem {
  id: string;
  name: string;
  amount: number;
  type: 'Fijo' | 'Variable' | 'Mixto' | 'Sin clasificar';
  aiSuggestion?: string;
}

export interface CanvasDoc {
  id: 'singleton';
  blocks: Record<string, string>;
  updatedAt: string;
}

export interface MarketingPlan {
    id: 'singleton';
    objective: string;
    segment: string;
    valueProposition: string;
    product: string;
    price: string;
    place: string;
    promotion: string;
    actions: { text: string; completed: boolean }[];
    budget: number;
    updatedAt: string;
}
